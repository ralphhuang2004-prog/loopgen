// LegalLayout.jsx — Shared layout for all LoopGen legal pages
// Drop-in for React/Vite. Handles nav, table of contents, and consistent styling.
// Usage: wrap any legal page content in <LegalLayout pageId="terms">...</LegalLayout>

import { useState, useEffect, useRef } from "react";

export const LEGAL_PAGES = [
  { id: "terms",        path: "/terms",             label: "Terms of Service" },
  { id: "privacy",      path: "/privacy",            label: "Privacy Policy" },
  { id: "cookies",      path: "/legal/cookies",      label: "Cookie Policy" },
  { id: "community",    path: "/legal/community",    label: "Community Guidelines" },
  { id: "prohibited",   path: "/legal/prohibited",   label: "Prohibited Items" },
  { id: "buyer",        path: "/legal/buyer",        label: "Buyer Protection" },
  { id: "seller",       path: "/legal/seller",       label: "Seller Policy" },
  { id: "refunds",      path: "/legal/refunds",      label: "Refund & Disputes" },
  { id: "antiscam",     path: "/legal/antiscam",     label: "Anti-Scam Policy" },
  { id: "verification", path: "/legal/verification", label: "Seller Verification" },
  { id: "trust",        path: "/trust",              label: "Trust & Safety" },
];

const EFFECTIVE = "1 July 2025";

// ── Inline styles (no Tailwind dependency — works standalone) ────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300;0,9..144,600;0,9..144,700;1,9..144,400&family=DM+Sans:wght@300;400;500;600&display=swap');

  :root {
    --green:      #1c7c45;
    --green-dark: #14532d;
    --green-mid:  #166534;
    --green-light:#dcfce7;
    --green-xl:   #f0fdf4;
    --amber:      #d97706;
    --amber-l:    #fef3c7;
    --blue:       #1d4ed8;
    --blue-l:     #dbeafe;
    --slate:      #334155;
    --slate-l:    #f8fafc;
    --border:     #e2e8f0;
    --text:       #1e293b;
    --muted:      #64748b;
    --white:      #ffffff;
    --font-head:  'Fraunces', Georgia, serif;
    --font-body:  'DM Sans', system-ui, sans-serif;
    --radius:     10px;
    --shadow:     0 1px 3px rgba(0,0,0,.07), 0 4px 16px rgba(0,0,0,.06);
  }

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  body {
    font-family: var(--font-body);
    font-size: 15px;
    line-height: 1.7;
    color: var(--text);
    background: var(--white);
    -webkit-font-smoothing: antialiased;
  }

  /* ── Top bar ── */
  .lg-topbar {
    background: var(--green);
    padding: 0 28px;
    height: 54px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    position: sticky;
    top: 0;
    z-index: 100;
    box-shadow: 0 1px 0 rgba(255,255,255,.1);
  }
  .lg-brand {
    display: flex;
    align-items: center;
    gap: 10px;
    text-decoration: none;
    color: #fff;
  }
  .lg-brand-mark {
    width: 30px;
    height: 30px;
    background: rgba(255,255,255,.15);
    border-radius: 7px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: var(--font-head);
    font-weight: 700;
    font-size: 16px;
    color: #fff;
    letter-spacing: -.5px;
  }
  .lg-brand-name {
    font-family: var(--font-head);
    font-weight: 600;
    font-size: 17px;
    letter-spacing: -.3px;
    color: #fff;
  }
  .lg-brand-tag {
    font-size: 11px;
    color: rgba(255,255,255,.6);
    font-style: italic;
    display: none;
  }
  @media (min-width: 640px) { .lg-brand-tag { display: block; } }

  /* ── Shell ── */
  .lg-shell {
    display: grid;
    grid-template-columns: 240px 1fr;
    grid-template-rows: auto;
    max-width: 1140px;
    margin: 0 auto;
    min-height: calc(100vh - 54px);
  }
  @media (max-width: 820px) {
    .lg-shell { grid-template-columns: 1fr; }
    .lg-sidebar { display: none; }
  }

  /* ── Sidebar ── */
  .lg-sidebar {
    padding: 32px 16px 64px;
    border-right: 1px solid var(--border);
    position: sticky;
    top: 54px;
    height: calc(100vh - 54px);
    overflow-y: auto;
  }
  .lg-sidebar-title {
    font-size: 10px;
    font-weight: 600;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 10px;
    padding: 0 8px;
  }
  .lg-nav-item {
    display: flex;
    align-items: center;
    padding: 7px 8px;
    border-radius: 7px;
    font-size: 13.5px;
    color: var(--muted);
    text-decoration: none;
    transition: all .15s;
    cursor: pointer;
    background: none;
    border: none;
    width: 100%;
    text-align: left;
    gap: 8px;
  }
  .lg-nav-item:hover { background: var(--slate-l); color: var(--text); }
  .lg-nav-item.active { background: var(--green-light); color: var(--green-dark); font-weight: 500; }
  .lg-nav-dot {
    width: 6px; height: 6px; border-radius: 50%;
    background: currentColor; opacity: .4; flex-shrink: 0;
  }
  .lg-nav-item.active .lg-nav-dot { opacity: 1; }

  /* ── Main content ── */
  .lg-main {
    padding: 48px 52px 96px;
    max-width: 780px;
  }
  @media (max-width: 640px) { .lg-main { padding: 28px 20px 64px; } }

  /* ── Page header ── */
  .lg-page-header {
    margin-bottom: 40px;
    padding-bottom: 32px;
    border-bottom: 1px solid var(--border);
  }
  .lg-page-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--green-light);
    color: var(--green-dark);
    font-size: 11.5px;
    font-weight: 600;
    letter-spacing: .4px;
    padding: 4px 10px;
    border-radius: 20px;
    margin-bottom: 14px;
  }
  .lg-page-title {
    font-family: var(--font-head);
    font-size: 36px;
    font-weight: 600;
    color: var(--text);
    line-height: 1.15;
    letter-spacing: -.5px;
    margin-bottom: 10px;
  }
  @media (max-width: 640px) { .lg-page-title { font-size: 26px; } }
  .lg-page-meta {
    font-size: 13px;
    color: var(--muted);
    display: flex;
    gap: 16px;
    flex-wrap: wrap;
  }
  .lg-page-meta span { display: flex; align-items: center; gap: 5px; }

  /* ── TOC ── */
  .lg-toc {
    background: var(--slate-l);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 20px 24px;
    margin-bottom: 40px;
  }
  .lg-toc-title {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 12px;
  }
  .lg-toc-list { list-style: none; display: flex; flex-direction: column; gap: 4px; }
  .lg-toc-item a {
    font-size: 13.5px;
    color: var(--muted);
    text-decoration: none;
    display: flex;
    gap: 8px;
    align-items: baseline;
    padding: 2px 0;
    transition: color .15s;
  }
  .lg-toc-item a:hover { color: var(--green); }
  .lg-toc-item a .toc-num {
    font-size: 11px;
    color: var(--green);
    font-weight: 600;
    min-width: 20px;
  }

  /* ── Section typography ── */
  .lg-section { margin-bottom: 44px; scroll-margin-top: 80px; }
  .lg-section:last-child { margin-bottom: 0; }

  .lg-h2 {
    font-family: var(--font-head);
    font-size: 20px;
    font-weight: 600;
    color: var(--text);
    letter-spacing: -.2px;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .lg-h2::before {
    content: '';
    width: 3px; height: 20px;
    background: var(--green);
    border-radius: 2px;
    flex-shrink: 0;
  }
  .lg-h3 {
    font-size: 14px;
    font-weight: 600;
    color: var(--slate);
    letter-spacing: .1px;
    margin: 20px 0 8px;
    text-transform: uppercase;
  }
  .lg-p { font-size: 14.5px; color: var(--slate); margin-bottom: 12px; line-height: 1.75; }
  .lg-p:last-child { margin-bottom: 0; }

  /* ── Lists ── */
  .lg-list {
    list-style: none;
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin: 10px 0 14px;
    padding-left: 4px;
  }
  .lg-list li {
    font-size: 14px;
    color: var(--slate);
    display: flex;
    gap: 10px;
    align-items: flex-start;
    line-height: 1.65;
  }
  .lg-list li::before {
    content: '';
    width: 5px; height: 5px;
    background: var(--green);
    border-radius: 50%;
    margin-top: 8px;
    flex-shrink: 0;
  }
  .lg-list.alpha li::before { display: none; }
  .lg-list.alpha { counter-reset: alpha-counter; }
  .lg-list.alpha li { counter-increment: alpha-counter; }
  .lg-list.alpha li::before { display: none; }
  .lg-list.alpha li .alpha-num {
    font-size: 12px;
    font-weight: 600;
    color: var(--green);
    min-width: 18px;
  }

  /* ── Callout boxes ── */
  .lg-callout {
    border-radius: var(--radius);
    padding: 16px 20px;
    margin: 18px 0;
    border-left: 3px solid;
  }
  .lg-callout.green {
    background: var(--green-xl);
    border-color: var(--green);
  }
  .lg-callout.amber {
    background: var(--amber-l);
    border-color: var(--amber);
  }
  .lg-callout.blue {
    background: var(--blue-l);
    border-color: var(--blue);
  }
  .lg-callout-title {
    font-size: 12px;
    font-weight: 700;
    letter-spacing: .5px;
    text-transform: uppercase;
    margin-bottom: 6px;
  }
  .lg-callout.green .lg-callout-title { color: var(--green-dark); }
  .lg-callout.amber .lg-callout-title { color: #92400e; }
  .lg-callout.blue  .lg-callout-title { color: var(--blue); }
  .lg-callout p { font-size: 13.5px; line-height: 1.65; }
  .lg-callout.green p { color: #166534; }
  .lg-callout.amber p { color: #78350f; }
  .lg-callout.blue  p { color: #1e3a8a; }

  /* ── Checkbox items ── */
  .lg-checkbox-list { display: flex; flex-direction: column; gap: 8px; margin: 12px 0; }
  .lg-checkbox-item {
    display: flex; gap: 10px; align-items: flex-start;
    font-size: 14px; color: var(--slate); line-height: 1.6;
  }
  .lg-checkbox-box {
    width: 16px; height: 16px;
    border: 2px solid var(--green);
    border-radius: 4px;
    flex-shrink: 0;
    margin-top: 2px;
    display: flex; align-items: center; justify-content: center;
  }
  .lg-checkbox-box.checked { background: var(--green); }
  .lg-checkbox-box.checked::after { content: '✓'; color: #fff; font-size: 10px; font-weight: 700; }

  /* ── Tables ── */
  .lg-table-wrap { overflow-x: auto; margin: 14px 0; border-radius: var(--radius); border: 1px solid var(--border); }
  .lg-table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
  .lg-table thead tr { background: var(--green); }
  .lg-table thead th { color: #fff; font-weight: 600; padding: 11px 14px; text-align: left; font-size: 12px; letter-spacing: .3px; }
  .lg-table tbody tr:nth-child(even) { background: var(--slate-l); }
  .lg-table tbody tr:hover { background: var(--green-xl); transition: background .1s; }
  .lg-table tbody td { padding: 10px 14px; color: var(--slate); border-top: 1px solid var(--border); }
  .lg-table tbody td:first-child { font-weight: 600; color: var(--text); }

  /* ── Trust score viz ── */
  .trust-formula {
    background: linear-gradient(135deg, var(--green), #0f4c2a);
    border-radius: 12px;
    padding: 28px 32px;
    margin: 20px 0;
    color: #fff;
  }
  .trust-formula-label {
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    color: rgba(255,255,255,.6);
    margin-bottom: 12px;
  }
  .trust-formula-eq {
    font-family: var(--font-head);
    font-size: 22px;
    font-weight: 600;
    line-height: 1.5;
    color: #fff;
  }
  .trust-formula-eq .plus { color: rgba(255,255,255,.4); margin: 0 6px; }
  .trust-components {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 10px;
    margin: 20px 0;
  }
  .trust-component {
    background: var(--green-xl);
    border: 1px solid var(--green-light);
    border-radius: 8px;
    padding: 14px 16px;
  }
  .trust-component-name { font-weight: 600; font-size: 13px; color: var(--green-dark); margin-bottom: 4px; }
  .trust-component-pts { font-size: 11px; color: var(--muted); }
  .trust-component-bar { height: 4px; background: var(--green-light); border-radius: 2px; margin-top: 8px; overflow: hidden; }
  .trust-component-fill { height: 100%; background: var(--green); border-radius: 2px; }

  /* ── Verification badges ── */
  .badge-grid { display: flex; flex-wrap: wrap; gap: 10px; margin: 14px 0; }
  .badge {
    display: inline-flex; align-items: center; gap: 7px;
    padding: 7px 14px; border-radius: 20px;
    font-size: 13px; font-weight: 600;
  }
  .badge.green   { background: var(--green-light); color: var(--green-dark); }
  .badge.gold    { background: #fef3c7; color: #92400e; }
  .badge.blue    { background: var(--blue-l); color: var(--blue); }
  .badge.slate   { background: var(--slate-l); color: var(--slate); }

  /* ── Verification levels ── */
  .level-card {
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 20px 22px;
    margin-bottom: 12px;
    display: flex; gap: 16px; align-items: flex-start;
  }
  .level-icon {
    width: 40px; height: 40px; border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    font-size: 18px; flex-shrink: 0;
  }
  .level-icon.l1 { background: var(--blue-l); }
  .level-icon.l2 { background: var(--green-light); }
  .level-icon.l3 { background: #fef3c7; }
  .level-title { font-weight: 600; font-size: 15px; color: var(--text); margin-bottom: 4px; }
  .level-sub { font-size: 13px; color: var(--muted); margin-bottom: 8px; }

  /* ── Score meter ── */
  .score-meter {
    display: flex; flex-direction: column; gap: 8px; margin: 14px 0;
  }
  .score-tier {
    display: grid; grid-template-columns: 80px 1fr 90px;
    align-items: center; gap: 12px;
  }
  .score-range { font-size: 12px; font-weight: 600; color: var(--text); }
  .score-bar-bg { height: 8px; border-radius: 4px; background: var(--border); overflow: hidden; }
  .score-bar-fill { height: 100%; border-radius: 4px; }
  .score-label { font-size: 12px; color: var(--muted); text-align: right; }

  /* ── Risk items ── */
  .risk-item {
    display: flex; gap: 14px; align-items: flex-start;
    padding: 14px 16px;
    border-radius: 8px;
    margin-bottom: 8px;
    border: 1px solid var(--border);
  }
  .risk-icon { font-size: 20px; flex-shrink: 0; margin-top: 1px; }
  .risk-label { font-weight: 600; font-size: 14px; margin-bottom: 3px; }
  .risk-desc  { font-size: 13px; color: var(--muted); }

  /* ── Page footer ── */
  .lg-footer {
    margin-top: 64px;
    padding-top: 28px;
    border-top: 1px solid var(--border);
    display: flex; justify-content: space-between; align-items: center;
    flex-wrap: wrap; gap: 12px;
  }
  .lg-footer-left { font-size: 12.5px; color: var(--muted); }
  .lg-footer-links { display: flex; gap: 14px; flex-wrap: wrap; }
  .lg-footer-links a { font-size: 12.5px; color: var(--muted); text-decoration: none; }
  .lg-footer-links a:hover { color: var(--green); }

  /* ── Mobile nav toggle ── */
  .lg-mobile-nav {
    display: none;
    background: var(--slate-l);
    border-bottom: 1px solid var(--border);
    padding: 12px 20px;
    gap: 8px;
    flex-wrap: wrap;
  }
  @media (max-width: 820px) { .lg-mobile-nav { display: flex; } }
  .lg-mobile-nav a {
    font-size: 12px; color: var(--muted); text-decoration: none;
    padding: 4px 10px; border-radius: 16px; background: var(--white);
    border: 1px solid var(--border); white-space: nowrap;
  }
  .lg-mobile-nav a.active { background: var(--green-light); color: var(--green-dark); border-color: transparent; }
`;

// ── Sub-components ───────────────────────────────────────────────────────

export function Section({ id, children }) {
  return <section id={id} className="lg-section">{children}</section>;
}
export function H2({ children }) {
  return <h2 className="lg-h2">{children}</h2>;
}
export function H3({ children }) {
  return <h3 className="lg-h3">{children}</h3>;
}
export function P({ children }) {
  return <p className="lg-p">{children}</p>;
}
export function Ul({ children, alpha }) {
  return <ul className={`lg-list${alpha ? " alpha" : ""}`}>{children}</ul>;
}
export function Li({ children, num }) {
  if (num) return <li><span className="alpha-num">{num}</span>{children}</li>;
  return <li>{children}</li>;
}
export function Callout({ title, children, type = "green" }) {
  return (
    <div className={`lg-callout ${type}`}>
      {title && <div className="lg-callout-title">{title}</div>}
      {children}
    </div>
  );
}
export function DataTable({ headers, rows }) {
  return (
    <div className="lg-table-wrap">
      <table className="lg-table">
        <thead><tr>{headers.map((h,i) => <th key={i}>{h}</th>)}</tr></thead>
        <tbody>{rows.map((r,i) => <tr key={i}>{r.map((c,j) => <td key={j}>{c}</td>)}</tr>)}</tbody>
      </table>
    </div>
  );
}
export function CheckItem({ checked, children }) {
  return (
    <div className="lg-checkbox-item">
      <div className={`lg-checkbox-box${checked ? " checked" : ""}`} />
      <span>{children}</span>
    </div>
  );
}

// ── Main layout ──────────────────────────────────────────────────────────

export default function LegalLayout({ pageId, title, badge, sections = [], children }) {
  const [active, setActive] = useState(null);
  const mainRef = useRef(null);

  // Scroll spy
  useEffect(() => {
    if (!sections.length) return;
    const obs = new IntersectionObserver(
      entries => {
        const visible = entries.filter(e => e.isIntersecting);
        if (visible.length) setActive(visible[0].target.id);
      },
      { rootMargin: "-60px 0px -60% 0px", threshold: 0 }
    );
    sections.forEach(s => {
      const el = document.getElementById(s.id);
      if (el) obs.observe(el);
    });
    return () => obs.disconnect();
  }, [sections]);

  const currentPage = LEGAL_PAGES.find(p => p.id === pageId);

  return (
    <>
      <style>{css}</style>

      {/* Top bar */}
      <header className="lg-topbar">
        <a href="/" className="lg-brand">
          <div className="lg-brand-mark">L</div>
          <span className="lg-brand-name">LoopGen</span>
          <span className="lg-brand-tag">The next generation marketplace</span>
        </a>
        <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
          Legal &amp; Trust Documentation
        </span>
      </header>

      {/* Mobile nav strip */}
      <nav className="lg-mobile-nav">
        {LEGAL_PAGES.map(pg => (
          <a key={pg.id} href={pg.path} className={pg.id === pageId ? "active" : ""}>{pg.label}</a>
        ))}
      </nav>

      <div className="lg-shell">
        {/* Sidebar */}
        <aside className="lg-sidebar">
          <div className="lg-sidebar-title">Legal Pages</div>
          {LEGAL_PAGES.map(pg => (
            <a key={pg.id} href={pg.path} className={`lg-nav-item${pg.id === pageId ? " active" : ""}`}>
              <span className="lg-nav-dot" />
              {pg.label}
            </a>
          ))}
        </aside>

        {/* Main */}
        <main className="lg-main" ref={mainRef}>
          {/* Page header */}
          <div className="lg-page-header">
            <div className="lg-page-badge">
              <span>📋</span> Legal &amp; Policy
            </div>
            <h1 className="lg-page-title">{title}</h1>
            <div className="lg-page-meta">
              <span>📅 Effective {EFFECTIVE}</span>
              <span>🇦🇺 Australia — all states &amp; territories</span>
              {badge && <span>🏷 {badge}</span>}
            </div>
          </div>

          {/* TOC */}
          {sections.length > 0 && (
            <nav className="lg-toc" aria-label="Table of contents">
              <div className="lg-toc-title">Contents</div>
              <ul className="lg-toc-list">
                {sections.map((s, i) => (
                  <li key={s.id} className="lg-toc-item">
                    <a href={`#${s.id}`}>
                      <span className="toc-num">{i + 1}.</span>
                      {s.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          )}

          {/* Content */}
          {children}

          {/* Footer */}
          <footer className="lg-footer">
            <div className="lg-footer-left">
              © {new Date().getFullYear()} NexaraX Pty Ltd (ACN: 696 134 620 / ABN: 43 696 134 620)<br/>
              2 Patricia Road, Blackburn VIC 3130, Australia · {currentPage?.label}
            </div>
            <div className="lg-footer-links">
              {LEGAL_PAGES.filter(p => p.id !== pageId).slice(0, 4).map(p => (
                <a key={p.id} href={p.path}>{p.label}</a>
              ))}
            </div>
          </footer>
        </main>
      </div>
    </>
  );
}
