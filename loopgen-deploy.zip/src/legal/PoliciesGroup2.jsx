// /legal/buyer — Buyer Protection Policy
// /legal/seller — Seller Policy
// /legal/refunds — Refund & Dispute Policy

import LegalLayout, { Section, H2, H3, P, Ul, Li, Callout, DataTable } from "./LegalLayout.jsx";

// ── Buyer Protection Policy ───────────────────────────────────────────────

export function BuyerProtectionPolicy() {
  return (
    <LegalLayout pageId="buyer" title="Buyer Protection Policy" badge="Buyer Safety" sections={[
      { id: "scope",     label: "What Is and Isn't Covered" },
      { id: "window",    label: "Protection Windows" },
      { id: "claim",     label: "How to Raise a Claim" },
      { id: "outcomes",  label: "Possible Outcomes" },
      { id: "acl",       label: "ACL Rights" },
    ]}>
      <Callout title="Important — LoopGen does not process payments" type="amber">
        <p>LoopGen is a classified marketplace and does not hold or transfer funds between buyers and sellers. LoopGen cannot compel refunds or transfers. This policy describes LoopGen's facilitation process and safety guidance. For financial recovery, contact your bank and Scamwatch: scamwatch.gov.au | 1300 302 502.</p>
      </Callout>

      <Section id="scope">
        <H2>1. Scope of Buyer Protection</H2>
        <H3>LoopGen's facilitation process applies when:</H3>
        <Ul>
          <Li>The seller fails to respond to a reasonable dispute raised by the buyer</Li>
          <Li>A listing is found to be fraudulent or involve a prohibited item</Li>
          <Li>The seller's conduct violates LoopGen's Terms or Community Guidelines</Li>
          <Li>A scam or deceptive conduct is substantiated by evidence</Li>
        </Ul>
        <H3>This process does not apply to:</H3>
        <Ul>
          <Li>Transactions where no payment was made through the platform (LoopGen does not process payments)</Li>
          <Li>Change-of-mind returns where the item matches the description</Li>
          <Li>Disputes raised outside LoopGen's process</Li>
          <Li>Items described as "sold as-is" or "faulty" where the buyer accepted those terms</Li>
        </Ul>
      </Section>

      <Section id="window">
        <H2>2. Reporting Windows</H2>
        <DataTable
          headers={["Scenario", "Reporting Window"]}
          rows={[
            ["Item significantly not as described", "Report within 7 days of receiving the item"],
            ["Seller unresponsive after agreed sale", "Escalate after 48 hours of no response"],
            ["Suspected scam — no item received", "Report within 21 days of payment"],
            ["Counterfeit / fake item received", "Report within 7 days of receiving the item"],
          ]}
        />
      </Section>

      <Section id="claim">
        <H2>3. How to Raise a Claim</H2>
        <DataTable
          headers={["Step", "Action"]}
          rows={[
            ["Step 1 — Direct contact", "Message the seller through LoopGen's in-app system. Describe the issue with photos. Most issues resolve here within 48 hours."],
            ["Step 2 — Escalate to LoopGen", "If unresolved after 48 hours, email disputes@loopgen.app with evidence (photos, messages, transaction details)."],
            ["Step 3 — LoopGen review", "Trust & Safety reviews evidence from both parties. Review completed within 3–5 business days."],
            ["Step 4 — Outcome", "LoopGen issues a non-binding facilitated recommendation and may take account action against the seller if fraud is established."],
          ]}
        />
        <Callout title="External remedies" type="blue">
          <p>You retain all rights to pursue remedies through Consumer Affairs in your state, the ACCC (accc.gov.au), state tribunals (VCAT, NCAT, etc.), or the courts. LoopGen's facilitation does not limit these rights.</p>
        </Callout>
      </Section>

      <Section id="outcomes">
        <H2>4. Possible Outcomes</H2>
        <DataTable
          headers={["Outcome", "Result"]}
          rows={[
            ["Fraud confirmed", "Seller permanently banned; reported to law enforcement; buyer referred to Scamwatch and bank for financial recovery"],
            ["Policy violation confirmed", "Seller warned or suspended; non-binding recommendation issued"],
            ["Unsubstantiated claim", "No platform action; buyer referred to Consumer Affairs for further options"],
            ["Mutual resolution", "Both parties confirm resolution; case closed"],
          ]}
        />
      </Section>

      <Section id="acl">
        <H2>5. Australian Consumer Law Rights</H2>
        <Callout title="ACL Rights Preserved" type="green">
          <p>LoopGen's facilitation process does not replace or limit your rights under the Australian Consumer Law. If goods fail to meet consumer guarantees (acceptable quality, fitness for purpose, matching description), you have statutory rights to seek a remedy directly from the seller — regardless of any LoopGen process outcome.</p>
        </Callout>
        <P>State consumer bodies: <a href="https://accc.gov.au" target="_blank" rel="noreferrer">accc.gov.au</a> (federal) · Consumer Affairs in your state/territory.</P>
      </Section>
    </LegalLayout>
  );
}

// ── Seller Policy ─────────────────────────────────────────────────────────

export function SellerPolicy() {
  return (
    <LegalLayout pageId="seller" title="Seller Policy" badge="Seller Responsibilities" sections={[
      { id: "becoming",  label: "Becoming a Seller" },
      { id: "listing",   label: "Listing Obligations" },
      { id: "conduct",   label: "Seller Conduct" },
      { id: "fees",      label: "Fees & Payouts" },
      { id: "trust",     label: "Trust Score" },
      { id: "acl",       label: "ACL Compliance" },
    ]}>
      <Section id="becoming">
        <H2>1. Becoming a Seller</H2>
        <P>Any registered LoopGen user may create listings. To sell, you must complete at least Level 1 (Email Verified) seller verification. See the <a href="/legal/verification">Seller Verification Policy</a> for full details.</P>
        <P>By listing on LoopGen, you agree to this Seller Policy, the Terms of Service, and all LoopGen policies.</P>
      </Section>

      <Section id="listing">
        <H2>2. Listing Obligations</H2>
        <P>As a seller, you warrant that:</P>
        <Ul>
          <Li>The listing description is accurate, complete, and not misleading in any respect</Li>
          <Li>All photographs are genuine images of the actual item — stock images or images of different items are prohibited</Li>
          <Li>All known defects, flaws, and material conditions have been disclosed</Li>
          <Li>You are the lawful owner of the item and have the right to sell it</Li>
          <Li>The item does not infringe any third-party intellectual property rights</Li>
          <Li>The item complies with the <a href="/legal/prohibited">Prohibited Items Policy</a></Li>
          <Li>The price is stated in AUD and is the true and full price</Li>
        </Ul>
      </Section>

      <Section id="conduct">
        <H2>3. Seller Conduct</H2>
        <Ul>
          <Li>Respond to buyer enquiries promptly and honestly</Li>
          <Li>Fulfil transactions you have agreed to — repeated cancellations negatively impact your Trust Score</Li>
          <Li>Remove listings promptly if an item is no longer available</Li>
          <Li>Do not solicit off-platform payments in a manner designed to remove buyer protections</Li>
        </Ul>
        <Callout title="Remember" type="green">
          <p>LoopGen does not process payments. Any payment arrangement is entirely between you and the buyer. Be transparent about your preferred payment method and the risks associated with each option.</p>
        </Callout>
      </Section>

      <Section id="fees">
        <H2>4. Fees</H2>
        <P>Listing fees are disclosed before submission and charged upon activation. They are non-refundable once live (subject to ACL). See the <a href="/legal/terms">Terms of Service</a> for the full fee schedule.</P>
      </Section>

      <Section id="trust">
        <H2>5. Trust Score</H2>
        <P>Your Trust Score (0–100) influences listing visibility and buyer confidence. It is calculated from: your verification level, buyer ratings, successful transaction history, account age, and average response speed. See the <a href="/legal/trust">Trust & Safety Architecture</a> for the full formula and tier details.</P>
      </Section>

      <Section id="acl">
        <H2>6. Australian Consumer Law Compliance</H2>
        <P>Sellers must comply with all applicable Australian laws, including:</P>
        <Ul>
          <Li>Australian Consumer Law — consumer guarantees apply to your sales</Li>
          <Li>Consumer Affairs obligations in your state or territory</Li>
          <Li>ATO requirements (ABN, GST, income reporting) where applicable</Li>
          <Li>Product safety standards for applicable categories</Li>
        </Ul>
        <P>LoopGen is not responsible for a seller's failure to comply with applicable law. Sellers indemnify LoopGen for any loss arising from their non-compliance.</P>
      </Section>
    </LegalLayout>
  );
}

// ── Refund & Dispute Policy ───────────────────────────────────────────────

export function RefundDisputePolicy() {
  return (
    <LegalLayout pageId="refunds" title="Refund & Dispute Policy" badge="Dispute Resolution" sections={[
      { id: "context",   label: "Important Context" },
      { id: "process",   label: "Dispute Process" },
      { id: "timeframes","label": "Timeframes" },
      { id: "external",  label: "External Remedies" },
    ]}>
      <Callout title="LoopGen does not process payments" type="amber">
        <p>Because LoopGen is a classified marketplace and does not hold funds, we cannot compel refunds between users. This policy explains our dispute facilitation process and directs users to appropriate external remedies for financial recovery.</p>
      </Callout>

      <Section id="context">
        <H2>1. Important Context</H2>
        <P>Transactions on LoopGen occur directly between buyers and sellers. LoopGen facilitates communication and may take platform action (account warnings, suspensions, bans) but cannot transfer funds or legally compel a seller to issue a refund.</P>
        <P>For financial recovery from a scam or failed transaction, your primary avenues are:</P>
        <Ul>
          <Li>Your bank or payment provider — contact them immediately if you have been defrauded</Li>
          <Li>Scamwatch: <a href="https://scamwatch.gov.au" target="_blank" rel="noreferrer">scamwatch.gov.au</a> · 1300 302 502</Li>
          <Li>Consumer Affairs in your state/territory</Li>
          <Li>ACCC: <a href="https://accc.gov.au" target="_blank" rel="noreferrer">accc.gov.au</a></Li>
          <Li>State tribunals (VCAT in VIC, NCAT in NSW, etc.) for civil recovery</Li>
        </Ul>
      </Section>

      <Section id="process">
        <H2>2. Dispute Process</H2>
        <DataTable
          headers={["Step", "Party", "Action", "Timeframe"]}
          rows={[
            ["1. Direct contact", "Buyer", "Message the seller in-app. Describe issue with photos and evidence.", "Day 1–2"],
            ["2. Escalation", "Buyer", "If no response in 48 hours, email disputes@loopgen.app with evidence.", "Day 3+"],
            ["3. Evidence submission", "Both parties", "LoopGen requests supporting evidence from both buyer and seller.", "48-hour window"],
            ["4. Review", "LoopGen", "Trust & Safety team reviews evidence and any prior account history.", "3–5 business days"],
            ["5. Recommendation", "LoopGen", "LoopGen issues a non-binding facilitated recommendation and any account actions.", "After review"],
            ["6. Appeal", "Either party", "Either party may appeal within 7 days with new evidence.", "7 days from decision"],
          ]}
        />
      </Section>

      <Section id="timeframes">
        <H2>3. Timeframes for Raising Issues</H2>
        <DataTable
          headers={["Scenario", "Window"]}
          rows={[
            ["Item not as described", "Within 7 days of receiving the item"],
            ["Item not received", "Within 21 days of purchase/payment"],
            ["Suspected scam", "As soon as possible — contact your bank immediately"],
            ["Counterfeit item received", "Within 7 days of receiving the item"],
            ["Appeal of LoopGen decision", "Within 7 days of receiving the decision"],
          ]}
        />
      </Section>

      <Section id="external">
        <H2>4. External Remedies</H2>
        <P>LoopGen's process does not limit your rights. You always retain the right to:</P>
        <Ul>
          <Li>Exercise your Australian Consumer Law rights directly against the seller</Li>
          <Li>Lodge a complaint with the ACCC or your state Consumer Affairs body</Li>
          <Li>Commence proceedings in an applicable state tribunal (VCAT, NCAT, QCAT, etc.)</Li>
          <Li>Report financial fraud to police or Crimestoppers: <strong>1800 333 000</strong></Li>
        </Ul>
      </Section>
    </LegalLayout>
  );
}
