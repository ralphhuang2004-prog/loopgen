// /legal/antiscam — Anti-Scam Policy
// /legal/verification — Seller Verification Policy

import LegalLayout, { Section, H2, H3, P, Ul, Li, Callout, DataTable } from "./LegalLayout.jsx";

// ── Anti-Scam Policy ──────────────────────────────────────────────────────

export function AntiScamPolicy() {
  return (
    <LegalLayout pageId="antiscam" title="Anti-Scam Policy" badge="Zero Tolerance for Fraud" sections={[
      { id: "commitment", label: "Our Commitment" },
      { id: "types",      label: "Common Scam Types" },
      { id: "detection",  label: "How We Detect Scams" },
      { id: "checklist",  label: "Safe Transaction Checklist" },
      { id: "report",     label: "If You Suspect a Scam" },
      { id: "consequences","label":"Consequences for Scammers" },
    ]}>
      <Callout title="Zero Tolerance Policy" type="amber">
        <p>LoopGen operates a zero-tolerance policy for scam activity. All confirmed scam accounts are permanently banned and reported to the ACCC, Scamwatch, and Australian Federal Police. LoopGen will never ask you to pay outside the platform or by cryptocurrency, gift card, or wire transfer.</p>
      </Callout>

      <Section id="commitment">
        <H2>1. Our Commitment</H2>
        <P>LoopGen invests in detection systems, manual review processes, and user education to minimise scam activity. We cooperate with the Australian Competition and Consumer Commission (ACCC), Scamwatch, and Australian Federal Police (AFP) where required.</P>
        <P>Because LoopGen does not process payments, buyers and sellers must exercise independent caution in their transactions. This policy exists to inform you of the risks and help you transact safely.</P>
      </Section>

      <Section id="types">
        <H2>2. Common Scam Types — Know What to Look For</H2>
        <DataTable
          headers={["Scam Type", "How It Works", "Warning Sign"]}
          rows={[
            ["Off-Platform Payment", "Seller or buyer asks you to pay outside LoopGen using bank transfer, crypto, or gift cards.", "Any request to pay outside normal channels"],
            ["Overpayment Scam", "Buyer sends excess payment, asks you to refund the difference. Original payment later reversed.", "Any payment larger than agreed price"],
            ["Fake LoopGen Emails", "Fraudster sends emails impersonating LoopGen requesting fees or credentials.", "Emails not from @loopgen.app domain"],
            ["Phishing", "Links or forms designed to steal your LoopGen login or payment details.", "Unexpected login prompts; unfamiliar URLs"],
            ["Ghost Listings", "In-demand items at suspiciously low prices from new accounts — item doesn't exist.", "New account + too-good-to-be-true price"],
            ["Trust Score Farming", "Multiple fake accounts used to generate artificial reviews and inflate Trust Score.", "Seller with many reviews but new account"],
          ]}
        />
      </Section>

      <Section id="detection">
        <H2>3. How LoopGen Detects Scams</H2>
        <Ul>
          <Li><strong>Automated risk scoring:</strong> Every listing and account receives a Risk Score (0–100). High-risk accounts and listings are held for review.</Li>
          <Li><strong>Pattern detection:</strong> High-value listings from new accounts, prices far below market rate, and messages containing payment links are automatically flagged.</Li>
          <Li><strong>Community reporting:</strong> Users can report suspicious listings, profiles, and messages instantly using the in-app Report button.</Li>
          <Li><strong>Seller verification:</strong> Verified sellers (Level 1, 2, 3) are less likely to be fraudulent — check verification badges before transacting.</Li>
          <Li><strong>Trust Score monitoring:</strong> Accounts with repeated disputes or low scores receive increased scrutiny and reduced visibility.</Li>
        </Ul>
      </Section>

      <Section id="checklist">
        <H2>4. Safe Transaction Checklist</H2>
        <Callout title="Before you pay anyone" type="green">
          <p>✅ Check the seller's Trust Score and verification badges</p>
          <p>✅ Review the seller's transaction history and reviews</p>
          <p>✅ Ask for additional photos or a short video of the item</p>
          <p>✅ Meet in person for high-value items where possible</p>
          <p>✅ Use a payment method that offers buyer protection (e.g., PayPal Goods & Services, credit card)</p>
          <p>❌ Never pay by cryptocurrency, gift cards, or wire transfer to strangers</p>
          <p>❌ Never share your LoopGen password, OTP, or banking credentials with anyone</p>
          <p>❌ Never send money before seeing and verifying the item exists</p>
        </Callout>
      </Section>

      <Section id="report">
        <H2>5. If You Suspect a Scam</H2>
        <Ul>
          <Li><strong>Stop immediately</strong> — do not send any payment if you haven't already</Li>
          <Li>Use the in-app <strong>Report</strong> button on the listing or profile</Li>
          <Li>Email <a href="mailto:safety@loopgen.app">safety@loopgen.app</a> with details</Li>
          <Li>If you have lost money, <strong>contact your bank immediately</strong></Li>
          <Li>Report to <strong>Scamwatch:</strong> <a href="https://scamwatch.gov.au" target="_blank" rel="noreferrer">scamwatch.gov.au</a> · 1300 302 502</Li>
          <Li>Report to <strong>ACCC:</strong> <a href="https://accc.gov.au" target="_blank" rel="noreferrer">accc.gov.au</a></Li>
          <Li>Contact police for criminal scam activity: <strong>000</strong> (emergency) or <strong>131 444</strong> (non-emergency)</Li>
        </Ul>
      </Section>

      <Section id="consequences">
        <H2>6. Consequences for Scammers</H2>
        <Ul>
          <Li>Immediate permanent account ban with no appeal</Li>
          <Li>Forfeiture of any pending or withheld fees</Li>
          <Li>Reporting to AFP, ACCC, and Scamwatch</Li>
          <Li>Civil recovery action for losses caused to LoopGen or users</Li>
          <Li>Criminal charges under the Criminal Code Act 1995 (Cth) or state law where applicable</Li>
        </Ul>
      </Section>
    </LegalLayout>
  );
}

// ── Seller Verification Policy ────────────────────────────────────────────

export function SellerVerificationPolicy() {
  return (
    <LegalLayout pageId="verification" title="Seller Verification Policy" badge="Trust & Verification" sections={[
      { id: "overview",    label: "Overview" },
      { id: "levels",      label: "Verification Levels" },
      { id: "trust-score", label: "Trust Score Formula" },
      { id: "tiers",       label: "Trust Score Tiers" },
      { id: "penalties",   label: "Score Penalties" },
      { id: "badges",      label: "Trust Badges" },
      { id: "data",        label: "Data Handling" },
    ]}>
      <Callout title="Why Verification Matters" type="green">
        <p>LoopGen's seller verification system exists to reduce anonymous fraud and build buyer confidence. Verified sellers receive increased visibility, higher Trust Scores, and access to premium features. Buyers should always check verification status before transacting.</p>
      </Callout>

      <Section id="overview">
        <H2>1. Overview</H2>
        <P>The Seller Verification System uses a tiered model to progressively establish seller identity and trustworthiness. Each level unlocks additional platform capabilities while adding accountability. Verification is required to sell on LoopGen.</P>
      </Section>

      <Section id="levels">
        <H2>2. Verification Levels</H2>
        <div className="level-card">
          <div className="level-icon l1">✉️</div>
          <div>
            <div className="level-title">Level 1 — Email Verified</div>
            <div className="level-sub">Email address confirmed via verification link</div>
            <ul className="lg-list" style={{marginTop:4}}>
              <li>List up to 5 items simultaneously</li>
              <li>Access to in-app messaging</li>
              <li>Basic Trust Score begins accumulating</li>
              <li>Displays "Email Verified" badge</li>
            </ul>
          </div>
        </div>
        <div className="level-card">
          <div className="level-icon l2">✅</div>
          <div>
            <div className="level-title">Level 2 — Payment Verified</div>
            <div className="level-sub">Valid payment method on file and verified</div>
            <ul className="lg-list" style={{marginTop:4}}>
              <li>Unlimited listing access (subject to policies)</li>
              <li>Enhanced Trust Score weighting</li>
              <li>Access to Featured Listings and Promoted Placements</li>
              <li>Displays "Payment Verified" badge</li>
              <li>Priority placement in search results</li>
            </ul>
          </div>
        </div>
        <div className="level-card">
          <div className="level-icon l3">🪪</div>
          <div>
            <div className="level-title">Level 3 — Identity Verified <span style={{fontSize:11,fontWeight:400,color:'var(--muted)'}}>Coming soon</span></div>
            <div className="level-sub">Government ID verified via accredited identity service</div>
            <ul className="lg-list" style={{marginTop:4}}>
              <li>Access to high-value categories (vintage jewellery, luxury goods, collectibles &gt;$2,000)</li>
              <li>Maximum Trust Score weighting</li>
              <li>Displays "Identity Verified" badge</li>
              <li>Dedicated account support</li>
            </ul>
          </div>
        </div>
      </Section>

      <Section id="trust-score">
        <H2>3. Trust Score Formula</H2>
        <P>Every seller on LoopGen has a Trust Score from 0 to 100, recalculated every 24 hours and displayed publicly on their profile and listings.</P>
        <div className="trust-formula">
          <div className="trust-formula-label">Trust Score Formula</div>
          <div className="trust-formula-eq">
            Trust Score<span className="plus">=</span>Verified Status<span className="plus">+</span>Buyer Ratings<span className="plus">+</span>Successful Transactions<span className="plus">+</span>Account Age<span className="plus">+</span>Response Speed
          </div>
        </div>
        <div className="trust-components">
          {[
            { name:"Verified Status", pts:"Max 25 pts", fill:"25", detail:"L1=10 | L2=20 | L3=25" },
            { name:"Buyer Ratings", pts:"Max 15 pts", fill:"15", detail:"(avg_rating/5) × 15" },
            { name:"Successful Transactions", pts:"Max 30 pts", fill:"30", detail:"1pt per sale (cap 30)" },
            { name:"Account Age", pts:"Max 20 pts", fill:"20", detail:"1pt per active month" },
            { name:"Response Speed", pts:"Max 10 pts", fill:"10", detail:"<2hrs=10 | >24hrs=0" },
          ].map(c => (
            <div key={c.name} className="trust-component">
              <div className="trust-component-name">{c.name}</div>
              <div className="trust-component-pts">{c.detail}</div>
              <div className="trust-component-bar">
                <div className="trust-component-fill" style={{width:`${c.fill}%`}} />
              </div>
            </div>
          ))}
        </div>
      </Section>

      <Section id="tiers">
        <H2>4. Trust Score Tiers & Platform Effects</H2>
        <div className="score-meter">
          {[
            { range:"0–10",   label:"Unestablished",  color:"#94a3b8", w:"10", desc:"Browse only. Cannot list." },
            { range:"11–25",  label:"New Seller",      color:"#60a5fa", w:"25", desc:"Up to 5 listings. Reduced placement." },
            { range:"26–50",  label:"Emerging Seller", color:"#34d399", w:"50", desc:"Standard access and placement." },
            { range:"51–75",  label:"Trusted Seller",  color:"#10b981", w:"75", desc:"Priority placement. Trusted badge." },
            { range:"76–90",  label:"Top Seller",      color:"#059669", w:"90", desc:"Featured sections. Promotion discounts." },
            { range:"91–100", label:"Star Seller",     color:"#d97706", w:"100", desc:"Homepage eligible. Dedicated support." },
          ].map(t => (
            <div key={t.range} className="score-tier">
              <div className="score-range">{t.range}</div>
              <div>
                <div className="score-bar-bg"><div className="score-bar-fill" style={{width:`${t.w}%`,background:t.color}} /></div>
              </div>
              <div className="score-label">{t.label}</div>
            </div>
          ))}
        </div>
        <DataTable
          headers={["Score Range", "Tier", "Platform Effect"]}
          rows={[
            ["0–10",   "Unestablished",  "Browse only. No listing access. No badge."],
            ["11–25",  "New Seller",     "Max 5 listings. Reduced search placement. Blue badge."],
            ["26–50",  "Emerging Seller","Standard listing access. Standard placement."],
            ["51–75",  "Trusted Seller", "Priority category placement. Green 'Trusted Seller' badge."],
            ["76–90",  "Top Seller",     "Featured sections eligible. Promoted listing discounts."],
            ["91–100", "Star Seller",    "Homepage eligible. Dedicated account support. Gold badge."],
          ]}
        />
      </Section>

      <Section id="penalties">
        <H2>5. Trust Score Penalties</H2>
        <DataTable
          headers={["Event", "Penalty"]}
          rows={[
            ["Upheld buyer dispute or complaint", "−5 points per event"],
            ["Unwarranted refund or cancellation", "−2 points per event"],
            ["Formal Trust & Safety warning", "−10 points per warning"],
            ["Temporary account suspension", "Score frozen during suspension"],
            ["Serious policy violation or fraud", "Score reset to 0; manual review required before relisting"],
          ]}
        />
      </Section>

      <Section id="badges">
        <H2>6. Trust Badges</H2>
        <div className="badge-grid">
          <span className="badge green">✉ Email Verified</span>
          <span className="badge green">✅ Payment Verified</span>
          <span className="badge blue">🪪 Identity Verified</span>
          <span className="badge green">💚 Trusted Trader</span>
          <span className="badge gold">⭐ Top Seller</span>
          <span className="badge slate">⚡ Fast Responder</span>
          <span className="badge gold">🌟 Star Seller</span>
        </div>
        <DataTable
          headers={["Badge", "Award Criteria"]}
          rows={[
            ["Email Verified", "Level 1 verification complete"],
            ["Payment Verified", "Level 2 verification complete"],
            ["Identity Verified", "Level 3 verification complete"],
            ["Trusted Trader", "Trust Score ≥ 51 with 20+ completed transactions"],
            ["Top Seller", "Trust Score ≥ 76 with consistent high performance"],
            ["Fast Responder", "30-day average response time under 2 hours"],
            ["Star Seller", "Trust Score 91–100 across all components"],
          ]}
        />
      </Section>

      <Section id="data">
        <H2>7. Verification Data Handling</H2>
        <P>All verification data is handled in compliance with the Privacy Act 1988 (Cth) and the Australian Privacy Principles:</P>
        <Ul>
          <Li>Email addresses are stored encrypted and used only for verification and platform communications</Li>
          <Li>Payment method details are processed by our PCI-DSS compliant payment processor — LoopGen does not store raw payment data</Li>
          <Li>Identity documents (Level 3) are processed by an accredited third-party identity verification service and are not retained by LoopGen beyond the verification event</Li>
          <Li>Verification status is stored as a level flag with timestamp — not raw document data</Li>
        </Ul>
      </Section>
    </LegalLayout>
  );
}
