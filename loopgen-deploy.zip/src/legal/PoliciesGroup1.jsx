// /legal/cookies — LoopGen Cookie Policy
import LegalLayout, { Section, H2, H3, P, Ul, Li, Callout, DataTable } from "./LegalLayout.jsx";

export function CookiePolicy() {
  return (
    <LegalLayout pageId="cookies" title="Cookie Policy" badge="Cookie Management" sections={[
      { id: "what",    label: "What Are Cookies?" },
      { id: "types",   label: "Types We Use" },
      { id: "manage",  label: "Managing Cookies" },
      { id: "dnt",     label: "Do Not Track" },
    ]}>
      <Section id="what">
        <H2>1. What Are Cookies?</H2>
        <P>Cookies are small text files placed on your device when you visit a website. LoopGen also uses similar technologies including local storage, session storage, and tracking pixels. They help us recognise your device, remember your preferences, and understand how you use our platform.</P>
      </Section>

      <Section id="types">
        <H2>2. Types of Cookies We Use</H2>
        <DataTable
          headers={["Type", "Purpose", "Can Disable?"]}
          rows={[
            ["Essential / Strictly Necessary", "Required for login sessions, security tokens, and core platform functions.", "No — required"],
            ["Functional", "Remember your preferences: language, saved filters, location settings.", "Yes"],
            ["Analytics & Performance", "Anonymised data on platform usage to identify improvements. (e.g., Google Analytics)", "Yes"],
            ["Marketing & Advertising", "Interest-based advertising on LoopGen and partner sites.", "Yes — opt-in only"],
            ["Third-Party", "Set by payment processors or social login providers. Governed by their policies.", "Varies"],
          ]}
        />
        <H3>Cookie Duration</H3>
        <DataTable
          headers={["Type", "Duration"]}
          rows={[
            ["Session cookies", "Deleted when you close your browser"],
            ["Persistent cookies", "30 days to 2 years, depending on purpose"],
            ["Third-party cookies", "Duration set by the third party"],
          ]}
        />
      </Section>

      <Section id="manage">
        <H2>3. Managing Your Cookies</H2>
        <P>You can manage cookie preferences at any time:</P>
        <Ul>
          <Li><strong>In-app:</strong> Account Settings → Cookie Preferences</Li>
          <Li><strong>Browser settings:</strong> Most browsers allow you to block or delete cookies in their settings menu</Li>
          <Li><strong>Opt-out tools:</strong> optout.networkadvertising.org for industry opt-outs</Li>
        </Ul>
        <P>Disabling essential cookies will impair LoopGen's core functionality.</P>
      </Section>

      <Section id="dnt">
        <H2>4. Do Not Track</H2>
        <P>LoopGen acknowledges Do Not Track (DNT) browser signals. When detected, we will not activate marketing or analytics cookies beyond what is strictly essential for platform operation.</P>
      </Section>
    </LegalLayout>
  );
}

// ── Community Guidelines ──────────────────────────────────────────────────

export function CommunityGuidelines() {
  return (
    <LegalLayout pageId="community" title="Community Guidelines" badge="Marketplace Standards" sections={[
      { id: "honest",    label: "Be Honest" },
      { id: "respect",   label: "Be Respectful" },
      { id: "fair",      label: "Transact Fairly" },
      { id: "legal",     label: "Keep It Legal" },
      { id: "privacy",   label: "Protect Privacy" },
      { id: "report",    label: "Reporting Violations" },
      { id: "consequences", label: "Consequences" },
    ]}>
      <Callout title="LoopGen is built on trust" type="green">
        <p>These guidelines exist to keep our community safe, fair, and enjoyable for everyone. Violations may result in listing removal, account suspension, or permanent banning. If you see something that violates these guidelines, use the in-app Report button.</p>
      </Callout>

      <Section id="honest">
        <H2>1. Be Honest</H2>
        <P>Honesty is the foundation of every LoopGen transaction.</P>
        <Ul>
          <Li>Describe items accurately — including all flaws, wear, damage, and defects</Li>
          <Li>Use real, unedited photographs of the actual item you are selling</Li>
          <Li>Don't misrepresent item age, brand, authenticity, or condition</Li>
          <Li>Set prices fairly and transparently — no hidden fees</Li>
          <Li>Don't create fake accounts, fake reviews, or artificial trust signals</Li>
        </Ul>
      </Section>

      <Section id="respect">
        <H2>2. Be Respectful</H2>
        <Ul>
          <Li>Communicate professionally and courteously with all users</Li>
          <Li>Do not use offensive, racist, sexist, homophobic, or discriminatory language</Li>
          <Li>Do not harass, threaten, intimidate, or stalk other users</Li>
          <Li>Do not send unsolicited promotional messages or spam</Li>
          <Li>Keep communications within LoopGen's in-app messaging system</Li>
        </Ul>
      </Section>

      <Section id="fair">
        <H2>3. Transact Fairly</H2>
        <Ul>
          <Li>Honour all agreed transactions — once a sale is confirmed, complete it</Li>
          <Li>Ship or hand over items promptly and as described</Li>
          <Li>Do not engage in price gouging, especially during emergencies or supply shortages</Li>
          <Li>Do not manipulate listings, reviews, or Trust Scores</Li>
        </Ul>
      </Section>

      <Section id="legal">
        <H2>4. Keep It Legal</H2>
        <Ul>
          <Li>Do not list, sell, or purchase any item that is illegal in Australia or the buyer's jurisdiction</Li>
          <Li>Do not infringe copyright, trade marks, or other intellectual property rights</Li>
          <Li>Comply with all applicable state and federal Australian laws</Li>
          <Li>Do not facilitate money laundering, fraud, or financial crime</Li>
        </Ul>
      </Section>

      <Section id="privacy">
        <H2>5. Protect Privacy</H2>
        <Ul>
          <Li>Do not share other users' personal information (address, phone, payment details) outside of LoopGen</Li>
          <Li>Do not attempt to obtain another user's personal details beyond what is necessary for a transaction</Li>
          <Li>Do not screenshot or share private conversations without consent</Li>
        </Ul>
      </Section>

      <Section id="report">
        <H2>6. Reporting Violations</H2>
        <P>If you see content or behaviour that violates these guidelines:</P>
        <Ul>
          <Li>Use the in-app <strong>Report</strong> button on any listing, profile, or message</Li>
          <Li>Email <a href="mailto:safety@loopgen.app">safety@loopgen.app</a> for urgent safety issues</Li>
          <Li>Contact Scamwatch at <a href="https://scamwatch.gov.au" target="_blank" rel="noreferrer">scamwatch.gov.au</a> for financial fraud</Li>
          <Li>Contact the ACCC at <a href="https://accc.gov.au" target="_blank" rel="noreferrer">accc.gov.au</a> for consumer protection issues</Li>
          <Li>Contact police for criminal activity</Li>
        </Ul>
      </Section>

      <Section id="consequences">
        <H2>7. Consequences for Violations</H2>
        <DataTable
          headers={["Severity", "Consequence"]}
          rows={[
            ["First violation (minor)", "Formal warning. Content removed."],
            ["Repeated or moderate violation", "Temporary suspension (7–30 days)"],
            ["Serious violation (fraud, scam, counterfeit)", "Permanent account ban"],
            ["Criminal activity (CSAM, weapons, drugs)", "Immediate ban + mandatory law enforcement referral"],
          ]}
        />
      </Section>
    </LegalLayout>
  );
}

// ── Prohibited Items ──────────────────────────────────────────────────────

export function ProhibitedItemsPolicy() {
  return (
    <LegalLayout pageId="prohibited" title="Prohibited Items Policy" badge="Zero Tolerance" sections={[
      { id: "absolute",    label: "Absolutely Prohibited" },
      { id: "restricted",  label: "Restricted Items" },
      { id: "reporting",   label: "Reporting a Listing" },
    ]}>
      <Callout title="Immediate Removal Policy" type="amber">
        <p>Listing a prohibited item will result in immediate listing removal and may result in permanent account ban and referral to law enforcement. If you are unsure whether an item is permitted, contact support@loopgen.app before listing.</p>
      </Callout>

      <Section id="absolute">
        <H2>1. Absolutely Prohibited — No Exceptions</H2>

        <H3>Illegal Drugs & Substances</H3>
        <Ul>
          <Li>Controlled drugs and substances under the Criminal Code Act 1995 (Cth) or any state/territory law</Li>
          <Li>Synthetic drugs, research chemicals, or "designer drugs"</Li>
          <Li>Drug paraphernalia marketed or intended for illicit drug use</Li>
          <Li>Precursor chemicals used for drug manufacture</Li>
        </Ul>

        <H3>Weapons & Dangerous Items</H3>
        <Ul>
          <Li>Firearms, handguns, and rifles (including deactivated weapons not in compliance with law)</Li>
          <Li>Prohibited weapons under state/territory weapons laws (e.g., knuckledusters, throwing stars, switchblades)</Li>
          <Li>Explosives, detonators, and explosive precursors</Li>
          <Li>Tasers and stun guns where prohibited under state law</Li>
        </Ul>

        <H3>Stolen Goods</H3>
        <Ul>
          <Li>Any item reported stolen or reasonably suspected to be stolen</Li>
          <Li>Items with removed or altered serial numbers</Li>
          <Li>Goods where the seller cannot demonstrate lawful ownership</Li>
        </Ul>

        <H3>Counterfeit & Fake Products</H3>
        <Ul>
          <Li>Counterfeit branded goods — fake designer clothing, handbags, electronics, watches</Li>
          <Li>Items misrepresented as genuine ("replica", "inspired by") without clear disclosure</Li>
          <Li>Forged documents, certificates, or official credentials</Li>
          <Li>Pirated media, counterfeit software, and IP-infringing digital content</Li>
        </Ul>

        <H3>Hazardous Materials</H3>
        <Ul>
          <Li>Asbestos-containing materials</Li>
          <Li>Radioactive materials</Li>
          <Li>Mercury-containing products outside Australian regulatory approval</Li>
          <Li>Pesticides, herbicides, or chemicals not approved for public sale</Li>
          <Li>Products not meeting Australian safety standards (AS/NZS)</Li>
        </Ul>

        <H3>Other Prohibited Categories</H3>
        <Ul>
          <Li>Human remains, organs, blood, or tissue</Li>
          <Li>Protected wildlife and CITES-listed species or products derived from them</Li>
          <Li>Child exploitation material — mandatory AFP referral applies, no exceptions</Li>
          <Li>Counterfeit currency, fraudulent financial instruments, and stolen gift cards</Li>
          <Li>Hacking tools, malware, exploit kits, and stolen login credentials</Li>
          <Li>Items violating any applicable Australian federal, state, or territory law</Li>
        </Ul>
      </Section>

      <Section id="restricted">
        <H2>2. Restricted Items — Prior Approval Required</H2>
        <P>The following items may only be listed with LoopGen's prior written approval or under specific documented conditions:</P>
        <Ul>
          <Li>Vintage collectible knives — must comply with state weapons laws; proof required</Li>
          <Li>Antique items with restricted materials (e.g., pre-CITES antique ivory) — provenance documentation required</Li>
          <Li>Alcohol — only where resale is lawful in the relevant state/territory</Li>
          <Li>Firearms accessories — must comply with applicable firearms law in the seller's state</Li>
        </Ul>
        <P>Contact <a href="mailto:support@loopgen.app">support@loopgen.app</a> before listing a potentially restricted item.</P>
      </Section>

      <Section id="reporting">
        <H2>3. Reporting a Prohibited Listing</H2>
        <Ul>
          <Li>Click the <strong>Report</strong> button on any listing</Li>
          <Li>Select "Prohibited Item" as the report reason</Li>
          <Li>Email <a href="mailto:safety@loopgen.app">safety@loopgen.app</a> with the listing URL and details</Li>
          <Li>If criminal activity is involved, contact Crimestoppers on <strong>1800 333 000</strong></Li>
        </Ul>
      </Section>
    </LegalLayout>
  );
}
